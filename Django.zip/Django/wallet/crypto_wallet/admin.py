from django.contrib import admin
from .models import Crypto, ColumnName
# Register your models here.
admin.site.register(Crypto)
admin.site.register(ColumnName)