from django.apps import AppConfig


class CryptoWalletConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'crypto_wallet'
